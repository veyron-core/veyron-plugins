//! Glue: validate a request, dispatch to the right provider, and map the
//! result back to `stt`'s normalized shape.
//!
//!   - `sherpa` (local): transcribe in-process via sherpa-onnx — no HTTP,
//!     no `network` hop.
//!   - `openai` (cloud): build the multipart audio upload, send it through
//!     `network`'s `http_request` action, parse the transcript — same flow
//!     as `ai`'s `chat_completion` and `tts`'s cloud handlers.

use veyron_sdk::VeyronClient;

use crate::provider::{
    openai::OpenAiProvider, ModelInfo, Provider, TranscriptResult,
};
use crate::request::{self, Provider as ProviderKind, TranscribeParams};

/// `network`'s `http_request` response shape (see
/// `plugins/network/src/handler.rs::HttpResponseJson`) — only the fields
/// `stt` needs to decode.
#[derive(serde::Deserialize)]
struct NetworkHttpResponse {
    status: u16,
    body: String,
    body_encoding: String,
}

/// Handle one `stt_transcribe` action end to end. Returns the JSON to
/// place in `ActionResponse.data_json` on success, or a human-readable
/// error (never containing a resolved API key) on failure.
pub async fn handle_stt_transcribe(
    client: &mut VeyronClient,
    params_json: &[u8],
) -> Result<Vec<u8>, String> {
    let params = request::parse_request(params_json)?;

    let result = match params.provider {
        ProviderKind::Sherpa => crate::provider::sherpa::transcribe(&params)?,
        ProviderKind::OpenAi => transcribe_cloud(client, &params).await?,
    };

    serde_json::to_vec(&result).map_err(|e| format!("failed to encode response: {e}"))
}

/// Handle one `stt_models` action: list the models the provider exposes.
pub async fn handle_stt_models(
    _client: &mut VeyronClient,
    params_json: &[u8],
) -> Result<Vec<u8>, String> {
    let provider = request::parse_models_request(params_json)?;
    let models: Vec<ModelInfo> = match provider {
        ProviderKind::Sherpa => crate::provider::sherpa::models()?,
        ProviderKind::OpenAi => request::OPENAI_MODELS
            .iter()
            .map(|m| ModelInfo {
                id: m.to_string(),
                name: m.to_string(),
            })
            .collect(),
    };
    serde_json::to_vec(&models).map_err(|e| format!("failed to encode response: {e}"))
}

async fn transcribe_cloud(
    client: &mut VeyronClient,
    params: &TranscribeParams,
) -> Result<TranscriptResult, String> {
    let allowed = request::parse_allowed_key_envs(
        &std::env::var(request::ALLOWED_KEY_ENVS_ENV).unwrap_or_default(),
    );
    if !request::is_allowed_key_env(&params.api_key_env, &allowed) {
        return Err(format!(
            "api_key_env '{}' is not in the operator's {} allowlist",
            params.api_key_env,
            request::ALLOWED_KEY_ENVS_ENV
        ));
    }

    let api_key = std::env::var(&params.api_key_env).unwrap_or_default();
    if api_key.is_empty() {
        return Err(format!(
            "environment variable {} is not set",
            params.api_key_env
        ));
    }

    let provider: &dyn Provider = &OpenAiProvider;
    let http_req = provider.build_http_request(params, &api_key);
    let http_req_json = serde_json::to_vec(&http_req)
        .map_err(|e| format!("failed to encode outbound http request: {e}"))?;

    let action_timeout = request::NETWORK_MAX_TIMEOUT_MS.min(params.timeout_ms) as u32;
    let action_resp = client
        .send_action("http_request", &http_req_json, action_timeout)
        .await
        .map_err(|e| format!("network plugin call failed: {e}"))?;

    if action_resp.status != veyron_sdk::proto::ActionStatus::ActionOk as i32 {
        return Err(format!("network plugin error: {}", action_resp.error));
    }

    let net_resp: NetworkHttpResponse = serde_json::from_slice(&action_resp.data_json)
        .map_err(|e| format!("malformed network response: {e}"))?;

    if !(200..300).contains(&net_resp.status) {
        return Err(format!(
            "provider returned HTTP {}: {}",
            net_resp.status, net_resp.body
        ));
    }

    let body_bytes: Vec<u8> = match net_resp.body_encoding.as_str() {
        "base64" => {
            use base64::Engine;
            base64::engine::general_purpose::STANDARD
                .decode(&net_resp.body)
                .map_err(|e| format!("malformed base64 response body: {e}"))?
        }
        _ => net_resp.body.into_bytes(),
    };

    provider.parse_response(&body_bytes, params)
}

/// Convenience for tests: normalize a cloud provider's transcript body
/// without a live `network` hop. Not part of the plugin's public interface.
pub fn parse_cloud_body(
    body: &[u8],
    params: &TranscribeParams,
) -> Result<TranscriptResult, String> {
    let provider: &dyn Provider = &OpenAiProvider;
    provider.parse_response(body, params)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn openai_params() -> TranscribeParams {
        TranscribeParams {
            provider: ProviderKind::OpenAi,
            audio: vec![0x52, 0x49, 0x46, 0x46],
            format: crate::request::AudioFormat::Wav,
            sample_rate_hz: 0,
            num_channels: 1,
            language: None,
            prompt: None,
            temperature: None,
            api_key_env: "OPENAI_API_KEY".to_string(),
            base_url: None,
            model: None,
            timeout_ms: 30_000,
        }
    }

    #[test]
    fn parse_cloud_body_parses_openai_json() {
        let result = parse_cloud_body(br#"{"text": "Hello world."}"#, &openai_params()).unwrap();
        assert_eq!(result.text, "Hello world.");
        assert_eq!(result.model, "whisper-1");
    }

    #[test]
    fn parse_cloud_body_propagates_provider_errors() {
        let err = parse_cloud_body(b"not json", &openai_params()).unwrap_err();
        assert!(err.contains("malformed"), "error was: {err}");
    }

    #[test]
    fn parse_cloud_body_rejects_empty_transcript() {
        let err = parse_cloud_body(br#"{"text": ""}"#, &openai_params()).unwrap_err();
        assert!(err.contains("empty transcript"), "error was: {err}");
    }
}
